def cadena():
    suma = (( numero + 1 ) * numero)/2
    return f"Suma= {suma}"
numero = int(input("Escribe un número entero positivo: "))



print(cadena())