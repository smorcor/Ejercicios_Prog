def saaludo():
    
    return "Hola, " + nom + "."
nom = input("Escribe tu nombre: ")

print(saaludo())